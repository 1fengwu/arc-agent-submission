from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal
from urllib.parse import urlparse

from deepagents import GeneralPurposeSubagentProfile, FilesystemPermission, HarnessProfile, create_deep_agent, register_harness_profile
from deepagents.backends import CompositeBackend, FilesystemBackend, StateBackend
from deepagents._models import get_model_provider
from deepagents.backends.filesystem import _raise_if_symlink_loop
from langchain.agents.middleware.types import AgentMiddleware
from pydantic import BaseModel, Field, create_model

from agents.model.factory import create_arc_chat_model
from agents.runtime.contracts import AgentRuntimeContext
from agents.runtime.stage_discipline import StageDisciplineMiddleware
from core.path_compat import normalize_windows_extended_prefix_path, normalize_windows_extended_prefix_text

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from langchain.agents.middleware.types import ModelRequest, ModelResponse, ResponseT
    from langchain_core.tools import BaseTool


WORKSPACE_PREFIX = "/workspace"
SKILLS_PREFIX = "/skills"
DISABLED_BUILTIN_TOOLS = frozenset({"execute", "write_todos"})
_WINDOWS_PATH_COMPAT_APPLIED = False
_READ_FILE_FORMAT_PATCHED = False

class OpenAIGlobSchema(BaseModel):
    """OpenAI-compatible schema for the glob tool."""

    pattern: str = Field(description="Glob pattern to match files (e.g., '**/*.py', '*.txt', '/subdir/**/*.md').")
    path: str = Field(default=None, description="Base directory to search from. Defaults to the backend's default root.")


class OpenAIGrepSchema(BaseModel):
    """OpenAI-compatible schema for the grep tool."""

    pattern: str = Field(description="Text pattern to search for (literal string, not regex).")
    path: str = Field(default=None, description="Directory to search in. Defaults to current working directory.")
    glob: str = Field(default=None, description="Glob pattern to filter which files to search (e.g., '*.py').")
    output_mode: Literal["files_with_matches", "content", "count"] = Field(
        default="files_with_matches",
        description="Output format: 'files_with_matches' (file paths only, default), 'content' (matching lines with context), 'count' (match counts per file).",
    )


class DisableToolsMiddleware(AgentMiddleware[Any, Any, Any]):
    """Hide selected tools from model requests."""

    def __init__(self, *, disabled: frozenset[str]) -> None:
        self._disabled = disabled

    def wrap_model_call(
        self,
        request: "ModelRequest[Any]",
        handler: "Callable[[ModelRequest[Any]], ModelResponse[Any]]",
    ) -> "ModelResponse[Any]":
        return handler(request.override(tools=self._filter_tools(request.tools)))

    async def awrap_model_call(
        self,
        request: "ModelRequest[Any]",
        handler: "Callable[[ModelRequest[Any]], Awaitable[ModelResponse[ResponseT]]]",
    ) -> "ModelResponse[ResponseT]":
        return await handler(request.override(tools=self._filter_tools(request.tools)))

    def _filter_tools(self, tools: list[Any]) -> list[Any]:
        return [
            _normalize_tool_schema(tool)
            for tool in tools
            if _tool_name(tool) not in self._disabled
        ]


def build_stage_agent(
    *,
    name: str,
    stage: Literal["interface_design", "test_generation", "implementation"],
    model: str | object,
    system_prompt: str,
    response_format: object | None,
    workspace_root: str,
    writable_roots: list[str],
    skills: list[str] | None = None,
    permitted_skill_names: list[str] | None = None,
    memory: list[str] | None = None,
    tools: list[object] | None = None,
):
    """Create an agent instance with ARC's first-batch filesystem policy."""

    _apply_windows_filesystem_path_compat()
    _apply_unambiguous_read_file_format()
    root = Path(workspace_root).expanduser().resolve()
    routes = {
        f"{WORKSPACE_PREFIX}/": FilesystemBackend(
            root_dir=str(root),
            virtual_mode=True,
        ),
    }
    skills_root = _compiler_skills_root()
    if skills_root.exists():
        routes[f"{SKILLS_PREFIX}/"] = FilesystemBackend(
            root_dir=str(skills_root),
            virtual_mode=True,
        )
    backend = CompositeBackend(default=StateBackend(), routes=routes)

    resolved_model = create_arc_chat_model(model)
    _register_arc_tool_exclusions(model=model, resolved_model=resolved_model)
    resolved_skills = _resolve_source_paths(skills, root, skills_root, default=[f"{SKILLS_PREFIX}/"])

    return create_deep_agent(
        name=name,
        model=resolved_model,
        backend=backend,
        system_prompt=system_prompt,
        middleware=[
            StageDisciplineMiddleware(stage=stage),
            DisableToolsMiddleware(disabled=DISABLED_BUILTIN_TOOLS),
        ],
        tools=tools or [],
        skills=resolved_skills,
        memory=_resolve_source_paths(memory, root, skills_root, default=[]),
        permissions=_build_filesystem_permissions(
            root,
            writable_roots,
            skill_instruction_paths=_resolve_skill_instruction_paths(
                resolved_skills,
                skills_root,
                permitted_skill_names=permitted_skill_names,
            ),
        ),
        context_schema=AgentRuntimeContext,
        response_format=_resolve_response_format(response_format),
    )


def _apply_unambiguous_read_file_format() -> None:
    """Remove line-number padding from read_file output before agents copy it.

    The upstream filesystem middleware renders each line as a six-character
    line number plus a tab. Models can mistake that separator for indentation
    and then submit an `edit_file` anchor that cannot match the source.
    """
    global _READ_FILE_FORMAT_PATCHED
    if _READ_FILE_FORMAT_PATCHED:
        return

    import deepagents.middleware.filesystem as filesystem_middleware

    def format_without_line_numbers(content: str | list[str], start_line: int = 1) -> str:
        del start_line
        if isinstance(content, str):
            lines = content.split("\n")
            if lines and lines[-1] == "":
                lines = lines[:-1]
            return "\n".join(lines)
        return "\n".join(content)

    filesystem_middleware.format_content_with_line_numbers = format_without_line_numbers
    _READ_FILE_FORMAT_PATCHED = True


def _build_filesystem_permissions(
    root: Path,
    writable_roots: list[str],
    *,
    skill_instruction_paths: list[str],
) -> list[Any]:
    permissions: list[Any] = [
        FilesystemPermission(
            operations=["read", "write"],
            paths=[
                f"{WORKSPACE_PREFIX}/.arc",
                f"{WORKSPACE_PREFIX}/.arc/**",
                f"{WORKSPACE_PREFIX}/.git",
                f"{WORKSPACE_PREFIX}/.git/**",
                f"{WORKSPACE_PREFIX}/requirements",
                f"{WORKSPACE_PREFIX}/requirements/**",
                f"{WORKSPACE_PREFIX}/**/node_modules",
                f"{WORKSPACE_PREFIX}/**/node_modules/**",
                f"{WORKSPACE_PREFIX}/**/dist",
                f"{WORKSPACE_PREFIX}/**/dist/**",
                f"{WORKSPACE_PREFIX}/**/dist-ssr",
                f"{WORKSPACE_PREFIX}/**/dist-ssr/**",
                f"{WORKSPACE_PREFIX}/**/build",
                f"{WORKSPACE_PREFIX}/**/build/**",
                f"{WORKSPACE_PREFIX}/**/coverage",
                f"{WORKSPACE_PREFIX}/**/coverage/**",
                f"{WORKSPACE_PREFIX}/**/.vite",
                f"{WORKSPACE_PREFIX}/**/.vite/**",
                f"{WORKSPACE_PREFIX}/**/package-lock.json",
                f"{WORKSPACE_PREFIX}/**/yarn.lock",
                f"{WORKSPACE_PREFIX}/**/pnpm-lock.yaml",
                f"{WORKSPACE_PREFIX}/.env",
                f"{WORKSPACE_PREFIX}/.env.*",
                f"{WORKSPACE_PREFIX}/**/.env",
                f"{WORKSPACE_PREFIX}/**/.env.*",
            ],
            mode="deny",
        ),
        FilesystemPermission(
            operations=["read"],
            paths=[WORKSPACE_PREFIX, f"{WORKSPACE_PREFIX}/**"],
            mode="allow",
        ),
    ]

    if skill_instruction_paths:
        permissions.append(
            FilesystemPermission(
                operations=["read"],
                paths=skill_instruction_paths,
                mode="allow",
            )
        )

    write_paths = [
        virtual_path
        for path in writable_roots
        if str(path or "").strip()
        for virtual_path in _expand_write_permission_paths(path, root)
    ]
    if write_paths:
        permissions.append(
            FilesystemPermission(
                operations=["write"],
                paths=write_paths,
                mode="allow",
            )
        )

    permissions.append(
        FilesystemPermission(
            operations=["read", "write"],
            paths=["/**"],
            mode="deny",
        )
    )
    return permissions


def _resolve_skill_instruction_paths(
    sources: list[str],
    skills_root: Path,
    *,
    permitted_skill_names: list[str] | None = None,
) -> list[str]:
    """Allow direct reads only for stage-selected skill instruction files.

    Deep Agents discovers frontmatter by scanning skill *source* directories. ARC
    therefore passes `/skills/` as the source, then constrains model tool access
    to the exact instruction files selected for the current stage.
    """

    if permitted_skill_names is not None:
        paths = [
            f"{SKILLS_PREFIX}/{name}/SKILL.md"
            for name in dict.fromkeys(permitted_skill_names)
            if (skills_root / name / "SKILL.md").is_file()
        ]
        return paths

    paths: list[str] = []
    for source in sources:
        normalized = _normalize_virtual_path(source).rstrip("/")
        if not normalized.startswith(f"{SKILLS_PREFIX}/") and normalized != SKILLS_PREFIX:
            continue
        if normalized == SKILLS_PREFIX:
            for skill_file in skills_root.glob("*/SKILL.md"):
                paths.append(f"{SKILLS_PREFIX}/{skill_file.parent.name}/SKILL.md")
            continue
        if normalized.endswith("/SKILL.md"):
            paths.append(normalized)
        else:
            paths.append(f"{normalized}/SKILL.md")
    return list(dict.fromkeys(paths))


def _expand_write_permission_paths(path: str, root: Path) -> list[str]:
    normalized = _to_virtual_workspace_path(path, root).rstrip("/") or WORKSPACE_PREFIX
    return [normalized, f"{normalized}/**"]


def _register_arc_tool_exclusions(*, model: Any, resolved_model: Any) -> None:
    """Remove built-in agent tools that ARC does not want to expose."""

    profile = HarnessProfile(
        excluded_tools=DISABLED_BUILTIN_TOOLS,
        general_purpose_subagent=GeneralPurposeSubagentProfile(enabled=False),
    )
    registered: set[str] = set()
    if isinstance(model, str):
        provider, model_name = _split_model_name(model)
        if provider:
            for key in (provider, f"{provider}:{model_name}"):
                register_harness_profile(key, profile)
                registered.add(key)
    provider = get_model_provider(resolved_model)
    if provider and provider not in registered:
        register_harness_profile(provider, profile)


def _resolve_response_format(response_format: object | None) -> object | None:
    base_url = os.getenv("OPENAI_API_BASE", "").strip() or os.getenv("OPENAI_BASE_URL", "").strip()
    if base_url and not _is_openai_base_url(base_url):
        return None
    return response_format


def _apply_windows_filesystem_path_compat() -> None:
    """Normalize Windows extended-length paths before agent containment checks."""

    global _WINDOWS_PATH_COMPAT_APPLIED
    if _WINDOWS_PATH_COMPAT_APPLIED or os.name != "nt":
        return

    original_resolve_path = FilesystemBackend._resolve_path
    original_to_virtual_path = FilesystemBackend._to_virtual_path

    def _resolve_path_with_windows_compat(self: FilesystemBackend, key: str) -> Path:
        if not getattr(self, "virtual_mode", False):
            return original_resolve_path(self, key)

        raw_key = normalize_windows_extended_prefix_text(key)
        vpath = raw_key if raw_key.startswith("/") else "/" + raw_key
        if ".." in vpath or vpath.startswith("~"):
            raise ValueError("Path traversal not allowed")

        full = normalize_windows_extended_prefix_path((self.cwd / vpath.lstrip("/")).resolve())
        cwd = normalize_windows_extended_prefix_path(self.cwd)
        try:
            full.relative_to(cwd)
        except ValueError:
            msg = f"Path:{full} outside root directory: {cwd}"
            raise ValueError(msg) from None
        _raise_if_symlink_loop(full)
        return full

    def _to_virtual_path_with_windows_compat(self: FilesystemBackend, path: Path) -> str:
        if not getattr(self, "virtual_mode", False):
            return original_to_virtual_path(self, path)

        full = normalize_windows_extended_prefix_path(path.resolve())
        cwd = normalize_windows_extended_prefix_path(self.cwd)
        return "/" + full.relative_to(cwd).as_posix()

    FilesystemBackend._resolve_path = _resolve_path_with_windows_compat  # type: ignore[method-assign]
    FilesystemBackend._to_virtual_path = _to_virtual_path_with_windows_compat  # type: ignore[method-assign]
    _WINDOWS_PATH_COMPAT_APPLIED = True


def _is_openai_base_url(base_url: str) -> bool:
    host = urlparse(base_url).hostname or ""
    return host == "api.openai.com" or host.endswith(".openai.com")


def _resolve_source_paths(paths: list[str] | None, root: Path, skills_root: Path, *, default: list[str]) -> list[str]:
    candidates = paths if paths is not None else default
    resolved: list[str] = []
    for path in candidates:
        virtual_path = _to_virtual_source_path(path, root, skills_root)
        if not _virtual_path_exists(virtual_path, root, skills_root):
            continue
        if virtual_path not in resolved:
            resolved.append(virtual_path)
    return resolved


def _virtual_path_exists(virtual_path: str, root: Path, skills_root: Path) -> bool:
    if virtual_path == SKILLS_PREFIX or virtual_path.startswith(f"{SKILLS_PREFIX}/"):
        relative = virtual_path[len(SKILLS_PREFIX) :].lstrip("/")
        return (skills_root / relative).exists()
    if virtual_path == WORKSPACE_PREFIX or virtual_path.startswith(f"{WORKSPACE_PREFIX}/"):
        relative = virtual_path[len(WORKSPACE_PREFIX) :].lstrip("/")
        return (root / relative).exists()
    return False


def _to_virtual_source_path(path: str, root: Path, skills_root: Path) -> str:
    raw = str(path or "").strip().replace("\\", "/")
    if raw == SKILLS_PREFIX or raw.startswith(f"{SKILLS_PREFIX}/"):
        return _normalize_virtual_path(raw)

    candidate = Path(raw).expanduser()
    if candidate.is_absolute():
        try:
            relative = candidate.resolve().relative_to(skills_root)
        except ValueError:
            return _to_virtual_workspace_path(path, root)
        relative_text = relative.as_posix()
        if not relative_text or relative_text == ".":
            return SKILLS_PREFIX
        return _normalize_virtual_path(f"{SKILLS_PREFIX}/{relative_text}")

    return _to_virtual_workspace_path(path, root)


def _to_virtual_workspace_path(path: str, root: Path) -> str:
    raw = str(path or "").strip().replace("\\", "/")
    if not raw:
        return WORKSPACE_PREFIX

    candidate = Path(raw).expanduser()
    try:
        relative = candidate.resolve().relative_to(root.resolve())
    except ValueError as exc:
        if raw == WORKSPACE_PREFIX or raw.startswith(f"{WORKSPACE_PREFIX}/"):
            return _normalize_virtual_path(raw)
        if candidate.is_absolute():
            raise ValueError(f"Path `{path}` is outside workspace root `{root}`.") from exc
        relative = (root / candidate).resolve().relative_to(root.resolve())

    relative_text = relative.as_posix()
    if not relative_text or relative_text == ".":
        return WORKSPACE_PREFIX
    return _normalize_virtual_path(f"{WORKSPACE_PREFIX}/{relative_text}")


def _compiler_skills_root() -> Path:
    return Path(__file__).resolve().parents[2] / "skills"


def _normalize_virtual_path(path: str) -> str:
    normalized = "/" + str(path).strip().replace("\\", "/").strip("/")
    while "//" in normalized:
        normalized = normalized.replace("//", "/")
    if normalized != WORKSPACE_PREFIX and normalized.endswith("/"):
        return normalized.rstrip("/")
    return normalized


def _split_model_name(model: str) -> tuple[str, str]:
    if ":" not in model:
        return "", model.strip()
    provider, model_name = model.split(":", 1)
    return provider.strip().lower(), model_name.strip()


def _tool_name(tool: "BaseTool | dict[str, Any] | Any") -> str | None:
    if isinstance(tool, dict):
        name = tool.get("name")
        return name if isinstance(name, str) else None
    name = getattr(tool, "name", None)
    return name if isinstance(name, str) else None


def _normalize_tool_schema(tool: "BaseTool | dict[str, Any] | Any") -> "BaseTool | dict[str, Any] | Any":
    name = _tool_name(tool)
    if isinstance(tool, dict):
        copied = dict(tool)
        parameters = copied.get("parameters")
        if isinstance(parameters, dict):
            copied["parameters"] = _sanitize_json_schema(parameters)
        function = copied.get("function")
        if isinstance(function, dict) and isinstance(function.get("parameters"), dict):
            copied["function"] = {
                **function,
                "parameters": _sanitize_json_schema(function["parameters"]),
            }
        return copied

    schema = _openai_compatible_args_schema(tool, name)
    if schema is None:
        return tool
    if hasattr(tool, "model_copy"):
        return tool.model_copy(update={"args_schema": schema})
    return tool


def _openai_compatible_args_schema(tool: "BaseTool | Any", name: str | None) -> type[BaseModel] | None:
    if name == "glob":
        return OpenAIGlobSchema
    if name == "grep":
        return OpenAIGrepSchema

    args_schema = getattr(tool, "args_schema", None)
    if not isinstance(args_schema, type) or not issubclass(args_schema, BaseModel):
        return None
    raw_schema = args_schema.model_json_schema()
    if not _schema_needs_openai_normalization(raw_schema):
        return None
    return _build_openai_schema_model(name or "Tool", raw_schema)


def _schema_needs_openai_normalization(schema: dict[str, Any]) -> bool:
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return False
    return any(isinstance(prop, dict) and "type" not in prop for prop in properties.values())


def _build_openai_schema_model(tool_name: str, schema: dict[str, Any]) -> type[BaseModel]:
    properties = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
    required = set(schema.get("required") or [])
    fields: dict[str, tuple[Any, Any]] = {}
    for field_name, property_schema in properties.items():
        if not isinstance(field_name, str) or not isinstance(property_schema, dict):
            continue
        annotation = _annotation_from_json_schema(property_schema)
        default = ... if field_name in required else property_schema.get("default", None)
        description = property_schema.get("description")
        title = property_schema.get("title")
        fields[field_name] = (
            annotation,
            Field(default=default, description=description, title=title),
        )

    model_name = "".join(part for part in f"OpenAI{tool_name.title()}Schema" if part.isalnum())
    return create_model(model_name or "OpenAIToolSchema", __base__=BaseModel, **fields)


def _annotation_from_json_schema(schema: dict[str, Any]) -> Any:
    concrete = _first_non_null_schema(schema)
    schema_type = concrete.get("type")
    if schema_type == "string":
        return str
    if schema_type == "integer":
        return int
    if schema_type == "number":
        return float
    if schema_type == "boolean":
        return bool
    if schema_type == "array":
        item_annotation = _annotation_from_json_schema(concrete.get("items") or {})
        return list[item_annotation]
    if schema_type == "object":
        return dict[str, Any]
    return Any


def _first_non_null_schema(schema: dict[str, Any]) -> dict[str, Any]:
    any_of = schema.get("anyOf")
    if isinstance(any_of, list):
        for candidate in any_of:
            if isinstance(candidate, dict) and candidate.get("type") != "null":
                return candidate
    one_of = schema.get("oneOf")
    if isinstance(one_of, list):
        for candidate in one_of:
            if isinstance(candidate, dict) and candidate.get("type") != "null":
                return candidate
    return schema


def _sanitize_json_schema(schema: dict[str, Any]) -> dict[str, Any]:
    copied = dict(schema)
    copied.setdefault("type", "object")
    properties = copied.get("properties")
    if isinstance(properties, dict):
        copied["properties"] = {
            key: _sanitize_property_schema(value) if isinstance(value, dict) else value
            for key, value in properties.items()
        }
    return copied


def _sanitize_property_schema(schema: dict[str, Any]) -> dict[str, Any]:
    concrete = dict(_first_non_null_schema(schema))
    for key in ("default", "description", "title"):
        if key in schema and key not in concrete:
            concrete[key] = schema[key]
    if "type" not in concrete:
        concrete["type"] = "string"
    if concrete.get("type") == "object":
        return _sanitize_json_schema(concrete)
    if concrete.get("type") == "array" and isinstance(concrete.get("items"), dict):
        concrete["items"] = _sanitize_property_schema(concrete["items"])
    return concrete
