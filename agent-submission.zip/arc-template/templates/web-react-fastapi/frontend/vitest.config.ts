import { mergeConfig } from "vitest/config";

import viteConfig from "./vite.config";


export default mergeConfig(viteConfig, {
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: "./src/test/setup.ts",
    css: true,
  },
});

