"""CLI template tests."""
